create trigger actin_BEFORE_INSERT
  before INSERT
  on actin
  for each row
  BEGIN
	 if new.grade<0 or new.grade>100 then
 insert into xxxx values(1);
 end if;
END;

