create trigger actin_BEFORE_UPDATE
  before UPDATE
  on actin
  for each row
  BEGIN
	 if new.grade<0 or new.grade>100 then
 insert into xxxx values(1);
 end if;
END;

