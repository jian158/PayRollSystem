create trigger film_BEFORE_INSERT
  before INSERT
  on film
  for each row
  BEGIN
 if new.grade<0 or new.grade>100 then
 insert into xxxx values(1);
 end if;
 if new.dname='周星驰' then
	set new.ftype :='喜剧';
 end if;
END;

