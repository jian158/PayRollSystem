create trigger film_BEFORE_UPDATE
  before UPDATE
  on film
  for each row
  BEGIN
 if new.grade<0 or new.grade>100 then
 insert into xxxx values(1);
 end if;
END;

