create view act_leading as
  select
    `x`.`ACTID`      AS `ACTID`,
    `x`.`ANAME`      AS `ANAME`,
    `x`.`BYEAR`      AS `BYEAR`,
    count(0)         AS `COUNT(*)`,
    max(`y`.`GRADE`) AS `MAX(GRADE)`
  from `lab`.`actor` `x`
    join `lab`.`actin` `y`
  where ((`x`.`BYEAR` > 1980) and (`x`.`ACTID` = `y`.`ACTID`) and (`y`.`ISLEADING` = 'Y'))
  group by `x`.`ACTID`;

